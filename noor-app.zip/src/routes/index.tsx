import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { motion } from "framer-motion";
import { Mic } from "lucide-react";
import { StarryNight } from "@/components/StarryNight";
import { CrescentMoon } from "@/components/CrescentMoon";
import { NoorMascot, type MascotState } from "@/components/NoorMascot";
import { askNoor } from "@/lib/noor-chat.functions";
import { getRecognition, speak } from "@/lib/speech";
import { sounds } from "@/lib/audio-cues";

export const Route = createFileRoute("/")({
  component: NoorApp,
  head: () => ({
    meta: [
      { title: "Noor — Islamic Voice Buddy for Kids" },
      {
        name: "description",
        content:
          "Noor is a friendly Islamic voice assistant for children — Quran, kahaniyan aur duaein, sirf awaaz se.",
      },
    ],
  }),
});

const QUICK = [
  "Quran Parhein",
  "Kahani Sunayein",
  "Aaj Ki Dua",
  "Science Sawal",
] as const;

function NoorApp() {
  const ask = useServerFn(askNoor);
  const [state, setState] = useState<MascotState>("idle");
  const [statusText, setStatusText] = useState("");
  const messagesRef = useRef<{ role: "user" | "assistant"; content: string }[]>(
    [],
  );
  const transcriptRef = useRef("");
  const greetedRef = useRef(false);
  const recRef = useRef<any>(null);
  const silenceTimerRef = useRef<number | null>(null);

  const setSpeakingForText = useCallback((text: string) => {
    setState("speaking");
    speak(text, {
      onEnd: () => setState("idle"),
    });
  }, []);

  const sendToNoor = useCallback(
    async (userText: string) => {
      if (!userText.trim()) {
        setState("idle");
        return;
      }
      setState("thinking");
      messagesRef.current.push({ role: "user", content: userText });
      try {
        const res: any = await ask({
          data: { messages: messagesRef.current },
        });
        const reply = res?.reply || res?.error || "Pyare bache! Dobara koshish karo.";
        messagesRef.current.push({ role: "assistant", content: reply });
        sounds.done();
        setSpeakingForText(reply);
      } catch (e) {
        console.error(e);
        setSpeakingForText("Pyare bache! Kuch masla ho gaya. Dobara try karo.");
      }
    },
    [ask, setSpeakingForText],
  );

  // Auto greeting on mount
  useEffect(() => {
    if (greetedRef.current) return;
    greetedRef.current = true;
    const greeting =
      "Assalam-o-Alaikum Pyare Bache! Main Noor hoon. Batao, aaj kya seekhna hai?";
    messagesRef.current.push({ role: "assistant", content: greeting });
    const t = window.setTimeout(() => {
      try {
        sounds.welcome();
      } catch {}
      setSpeakingForText(greeting);
    }, 1000);
    return () => window.clearTimeout(t);
  }, [setSpeakingForText]);

  const startListening = useCallback(() => {
    if (state === "listening" || state === "thinking") return;
    // Cancel any ongoing TTS
    if (typeof window !== "undefined") window.speechSynthesis?.cancel();

    const rec = getRecognition();
    if (!rec) {
      setSpeakingForText(
        "Pyare bache! Aapke browser mein awaaz nahi sun sakta. Buttons istemal karein.",
      );
      return;
    }
    recRef.current = rec;
    transcriptRef.current = "";
    setStatusText("");
    sounds.listenStart();
    setState("listening");

    const resetSilence = () => {
      if (silenceTimerRef.current) window.clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = window.setTimeout(() => {
        try {
          rec.stop();
        } catch {}
      }, 2000);
    };

    rec.onresult = (e: any) => {
      const text = Array.from(e.results)
        .map((r: any) => r[0]?.transcript || "")
        .join(" ")
        .trim();
      transcriptRef.current = text;
      setStatusText(text);
      resetSilence();
    };
    rec.onspeechend = () => {
      try {
        rec.stop();
      } catch {}
    };
    rec.onerror = () => {
      setState("idle");
    };
    rec.onend = () => {
      if (silenceTimerRef.current) window.clearTimeout(silenceTimerRef.current);
      const final = transcriptRef.current.trim();
      if (final) {
        void sendToNoor(final);
      } else {
        setState("idle");
      }
    };

    try {
      rec.start();
      resetSilence();
    } catch {
      setState("idle");
    }
  }, [state, sendToNoor, setSpeakingForText]);

  const handleQuick = (phrase: string) => {
    if (state === "thinking" || state === "listening") return;
    if (typeof window !== "undefined") window.speechSynthesis?.cancel();
    void sendToNoor(phrase);
  };

  return (
    <main
      className="relative min-h-screen w-full overflow-hidden text-white"
      style={{ touchAction: "manipulation" }}
    >
      <StarryNight />

      <div className="relative z-10 flex min-h-screen flex-col items-center justify-between px-4 py-6 sm:py-10">
        {/* Top — moon */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2 }}
          className="mt-2 sm:mt-6"
        >
          <CrescentMoon state={state} />
        </motion.div>

        {/* Mascot */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.4 }}
          className="flex-1 flex items-center justify-center w-full"
        >
          <NoorMascot state={state} onTap={startListening} />
        </motion.div>

        {/* Name */}
        <motion.h1
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="text-5xl sm:text-6xl font-bold tracking-wide"
          style={{
            fontFamily: "'Brush Script MT', 'Lucida Handwriting', cursive",
            background:
              "linear-gradient(180deg, #fff3c4 0%, #f5c453 60%, #c98c1f 100%)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            filter: "drop-shadow(0 0 18px rgba(245,196,83,0.55))",
          }}
        >
          Noor
        </motion.h1>

        {/* Quick buttons */}
        <div className="mt-4 flex flex-wrap justify-center gap-2 max-w-md">
          {QUICK.map((q) => (
            <button
              key={q}
              onClick={() => handleQuick(q)}
              disabled={state === "listening" || state === "thinking"}
              className="px-4 py-2 rounded-full text-sm font-medium
                         bg-white/10 backdrop-blur border border-white/20
                         hover:bg-white/20 active:scale-95 transition
                         disabled:opacity-50"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Dock with mic */}
        <div className="mt-6 mb-2 flex flex-col items-center gap-3">
          <div
            className="relative flex items-center justify-center rounded-t-full px-10 pt-4 pb-2"
            style={{
              background:
                "linear-gradient(180deg, rgba(255,255,255,0.08), rgba(255,255,255,0.02))",
              border: "1px solid rgba(255,255,255,0.12)",
              borderBottom: "none",
            }}
          >
            <motion.button
              onClick={startListening}
              whileTap={{ scale: 0.92 }}
              animate={
                state === "listening"
                  ? { boxShadow: [
                      "0 0 0 0 rgba(245,196,83,0.6)",
                      "0 0 0 24px rgba(245,196,83,0)",
                    ] }
                  : {}
              }
              transition={{ duration: 1.2, repeat: Infinity }}
              disabled={state === "thinking"}
              className="size-16 rounded-full flex items-center justify-center
                         text-slate-900 shadow-xl disabled:opacity-60"
              style={{
                background:
                  state === "listening"
                    ? "radial-gradient(circle at 30% 30%, #fff8d8, #f5c453)"
                    : "radial-gradient(circle at 30% 30%, #fff8d8, #e0a93a)",
              }}
              aria-label="Tap to talk to Noor"
            >
              <Mic className="size-7" />
            </motion.button>
          </div>
          <p className="text-xs text-white/70 min-h-4">
            {state === "idle" && "Mic dabao aur Noor se baat karo"}
            {state === "listening" && "Sun raha hoon… boliye"}
            {state === "thinking" && "Soch raha hoon…"}
            {state === "speaking" && "Noor baat kar raha hai"}
          </p>
        </div>
      </div>
    </main>
  );
}
