import { motion } from "framer-motion";
import type { MascotState } from "./NoorMascot";

export function CrescentMoon({ state }: { state: MascotState }) {
  const brightness =
    state === "listening" ? 1.5 : state === "speaking" ? 1.3 : 1;

  return (
    <div className="relative flex items-center justify-center">
      <motion.div
        className="relative"
        animate={{
          scale: state === "thinking" ? [1, 1.15, 1] : [1, 1.05, 1],
          filter: [
            `drop-shadow(0 0 20px hsl(45 90% 70% / ${0.5 * brightness}))`,
            `drop-shadow(0 0 40px hsl(45 90% 70% / ${0.9 * brightness}))`,
            `drop-shadow(0 0 20px hsl(45 90% 70% / ${0.5 * brightness}))`,
          ],
        }}
        transition={{
          duration: state === "thinking" ? 1 : 3,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      >
        <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
          <defs>
            <radialGradient id="moonGrad" cx="40%" cy="40%" r="60%">
              <stop offset="0%" stopColor="#fff8d8" />
              <stop offset="100%" stopColor="#f5c453" />
            </radialGradient>
          </defs>
          <path
            d="M55 12 A30 30 0 1 0 55 68 A22 22 0 1 1 55 12 Z"
            fill="url(#moonGrad)"
          />
        </svg>
      </motion.div>

      {state === "thinking" && (
        <>
          {[0, 1, 2].map((i) => (
            <motion.span
              key={i}
              className="absolute size-1.5 rounded-full bg-amber-200"
              animate={{
                rotate: 360,
                x: Math.cos((i * 120 * Math.PI) / 180) * 50,
                y: Math.sin((i * 120 * Math.PI) / 180) * 50,
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "linear",
                delay: i * 0.3,
              }}
              style={{
                boxShadow: "0 0 8px hsl(45 90% 70%)",
              }}
            />
          ))}
        </>
      )}
    </div>
  );
}
