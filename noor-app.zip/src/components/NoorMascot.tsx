import { motion } from "framer-motion";
import mascotImg from "@/assets/noor-mascot.png";

export type MascotState = "idle" | "listening" | "thinking" | "speaking";

interface Props {
  state: MascotState;
  onTap: () => void;
}

export function NoorMascot({ state, onTap }: Props) {
  // Animation variants for each state
  const float: Record<MascotState, { y: number[]; rotate: number[] }> = {
    idle: { y: [0, -14, 0], rotate: [0, 1, 0] },
    listening: { y: [0, -4, 0], rotate: [0, -3, 0] },
    thinking: { y: [0, -6, 0], rotate: [0, 0, 0] },
    speaking: { y: [0, -8, 0], rotate: [0, 1, -1, 0] },
  };

  const transitions = {
    idle: { duration: 3, repeat: Infinity, ease: "easeInOut" as const },
    listening: { duration: 1.2, repeat: Infinity, ease: "easeInOut" as const },
    thinking: { duration: 2, repeat: Infinity, ease: "easeInOut" as const },
    speaking: { duration: 0.6, repeat: Infinity, ease: "easeInOut" as const },
  };

  const glowScale =
    state === "listening" ? 1.15 : state === "speaking" ? 1.1 : 1;

  return (
    <div className="relative flex items-center justify-center select-none">
      {/* Golden glow */}
      <motion.div
        aria-hidden
        className="absolute inset-0 m-auto rounded-full blur-3xl"
        style={{
          background:
            "radial-gradient(circle, hsl(45 90% 60% / 0.55), transparent 70%)",
          width: "85%",
          height: "85%",
        }}
        animate={{
          scale: state === "speaking" ? [1, 1.18, 1] : [glowScale, glowScale * 1.05, glowScale],
          opacity: state === "idle" ? [0.55, 0.75, 0.55] : [0.7, 0.95, 0.7],
        }}
        transition={{
          duration: state === "speaking" ? 0.5 : 2.5,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* Particles when listening */}
      {state === "listening" && (
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(8)].map((_, i) => (
            <motion.span
              key={i}
              className="absolute left-1/2 bottom-1/3 size-2 rounded-full bg-amber-200"
              initial={{ opacity: 0, y: 0, x: 0 }}
              animate={{
                opacity: [0, 1, 0],
                y: [-10, -120],
                x: [0, (i - 4) * 18],
              }}
              transition={{
                duration: 2.2,
                repeat: Infinity,
                delay: i * 0.25,
                ease: "easeOut",
              }}
            />
          ))}
        </div>
      )}

      <motion.button
        onClick={onTap}
        whileTap={{ scale: 0.97 }}
        className="relative z-10 cursor-pointer focus:outline-none"
        aria-label="Tap Noor to talk"
      >
        <motion.img
          src={mascotImg}
          alt="Noor mascot - your Islamic learning friend"
          width={1024}
          height={1024}
          className="w-[min(60vw,360px)] h-auto drop-shadow-[0_0_40px_rgba(255,200,80,0.45)]"
          animate={float[state]}
          transition={transitions[state]}
        />
        {/* Speaking mouth pulse overlay */}
        {state === "speaking" && (
          <motion.div
            className="absolute left-1/2 top-[38%] -translate-x-1/2 w-6 h-2 rounded-full bg-rose-400/70"
            animate={{ scaleY: [0.4, 1.4, 0.6, 1.2, 0.4], scaleX: [1, 1.1, 1] }}
            transition={{ duration: 0.4, repeat: Infinity }}
          />
        )}
      </motion.button>
    </div>
  );
}
