// Lightweight WebAudio chimes — no asset downloads.
let ctx: AudioContext | null = null;
function getCtx() {
  if (typeof window === "undefined") return null;
  if (!ctx) ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
  return ctx;
}

function tone(freq: number, duration: number, when = 0, type: OscillatorType = "sine", gain = 0.15) {
  const ac = getCtx();
  if (!ac) return;
  const t = ac.currentTime + when;
  const osc = ac.createOscillator();
  const g = ac.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t);
  g.gain.setValueAtTime(0, t);
  g.gain.linearRampToValueAtTime(gain, t + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, t + duration);
  osc.connect(g).connect(ac.destination);
  osc.start(t);
  osc.stop(t + duration + 0.05);
}

export const sounds = {
  welcome() {
    tone(523.25, 0.3, 0);
    tone(659.25, 0.3, 0.15);
    tone(783.99, 0.5, 0.3);
  },
  listenStart() {
    tone(880, 0.15, 0, "sine", 0.12);
  },
  done() {
    tone(659.25, 0.2, 0);
    tone(880, 0.3, 0.1);
  },
};
