import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const SYSTEM_PROMPT = `Tum Noor ho, ek expert Islamic child educator aur friendly AI buddy. Tumhara kaam 5 se 12 saal ke bachon ko Quran aur Islami kahaniyan sikhana hai. Hamesha Roman Urdu mein baat karo. Har jawab ki shuruaat 'Pyare bache!' ya 'Mera hoshyaar dost!' se karo. Jawab chhota aur simple rakho, 3-4 sentences maximum. Agar bacha Quran parhna chahe to Surah Ikhlas ki pehli ayat sunao aur phir usay dohrane ko kaho. Agar kahani chahe to ek chhoti Islami kahani sunao aur ant mein ek aasan sawaal zaroor poochho. Agar Science ya Math ka sawal ho to Islami nukta-e-nazar se simple explain karo. Kabhi sakht lehja mat istemal karo. Hamesha pyar aur hosla afzai karo. Har response 70 words se kam rakho.`;

const InputSchema = z.object({
  messages: z.array(
    z.object({
      role: z.enum(["user", "assistant"]),
      content: z.string(),
    }),
  ),
});

export const askNoor = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => InputSchema.parse(data))
  .handler(async ({ data }) => {
    // Prefer personal Gemini API key (for Vercel / self-hosting).
    // Fallback to Lovable AI Gateway if running on Lovable Cloud.
    const geminiKey = process.env.GEMINI_API_KEY;
    const lovableKey = process.env.LOVABLE_API_KEY;

    try {
      if (geminiKey) {
        // ---- Direct Google Gemini API ----
        const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
        const contents = data.messages.map((m) => ({
          role: m.role === "assistant" ? "model" : "user",
          parts: [{ text: m.content }],
        }));

        const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${geminiKey}`;
        const resp = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
            contents,
            generationConfig: { temperature: 0.8, maxOutputTokens: 250 },
          }),
        });

        if (!resp.ok) {
          const t = await resp.text();
          console.error("Gemini error:", resp.status, t);
          return { error: "Pyare bache! Kuch masla ho gaya. Dobara try karo." };
        }
        const json: any = await resp.json();
        const reply =
          json?.candidates?.[0]?.content?.parts?.[0]?.text ??
          "Pyare bache! Mujhe samajh nahi aaya, dobara poochho.";
        return { reply };
      }

      if (lovableKey) {
        // ---- Lovable AI Gateway fallback ----
        const resp = await fetch(
          "https://ai.gateway.lovable.dev/v1/chat/completions",
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${lovableKey}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model: "google/gemini-3-flash-preview",
              messages: [
                { role: "system", content: SYSTEM_PROMPT },
                ...data.messages,
              ],
            }),
          },
        );

        if (!resp.ok) {
          if (resp.status === 429)
            return { error: "Bohot zyada requests! Thori der baad try karein." };
          if (resp.status === 402)
            return { error: "Credits khatam ho gaye hain." };
          const t = await resp.text();
          console.error("AI gateway error:", resp.status, t);
          return { error: "Kuch ghalat ho gaya. Dobara try karein." };
        }
        const json: any = await resp.json();
        const reply =
          json?.choices?.[0]?.message?.content ??
          "Pyare bache! Mujhe samajh nahi aaya, dobara poochho.";
        return { reply };
      }

      return {
        error:
          "API key set nahi hai. Vercel mein GEMINI_API_KEY environment variable add karein.",
      };
    } catch (e) {
      console.error("askNoor failed:", e);
      return { error: "Pyare bache! Connection mein masla hai." };
    }
  });
