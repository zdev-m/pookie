// Web Speech API helpers (browser-only).

export function getRecognition(): any | null {
  if (typeof window === "undefined") return null;
  const SR =
    (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
  if (!SR) return null;
  const rec = new SR();
  rec.lang = "ur-PK";
  rec.interimResults = false;
  rec.continuous = false;
  rec.maxAlternatives = 1;
  return rec;
}

export function speak(
  text: string,
  opts: { onStart?: () => void; onEnd?: () => void } = {},
) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) {
    opts.onEnd?.();
    return;
  }
  // Cancel anything queued
  window.speechSynthesis.cancel();

  const u = new SpeechSynthesisUtterance(text);
  u.lang = "ur-PK";
  u.rate = 0.95;
  u.pitch = 1.1;
  u.volume = 1;

  // Try to pick the best matching voice
  const voices = window.speechSynthesis.getVoices();
  const preferred =
    voices.find((v) => v.lang?.toLowerCase().startsWith("ur")) ||
    voices.find((v) => v.lang?.toLowerCase().startsWith("hi")) ||
    voices.find((v) => /female|zira|samantha/i.test(v.name));
  if (preferred) u.voice = preferred;

  u.onstart = () => opts.onStart?.();
  u.onend = () => opts.onEnd?.();
  u.onerror = () => opts.onEnd?.();
  window.speechSynthesis.speak(u);
}
